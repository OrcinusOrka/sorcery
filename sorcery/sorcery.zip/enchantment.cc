#include "enchantment.h"

Enchantment::Enchantment(std::string name, std::string type,
                         int cost, std::vector<Effect> effects):
  Card{name, type, cost, effects} {}

Enchantment::~Enchantment() {}
